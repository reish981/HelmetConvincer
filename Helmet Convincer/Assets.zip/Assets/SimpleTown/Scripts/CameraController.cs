﻿using UnityEngine;
using System.Collections;

/// <summary>Controls how a given camera is orientated</summary>
public class CameraController : MonoBehaviour
{
    [SerializeField]
    private Transform target;
	/// <summary>The target property represents the camera's target for orientation.</summary>
    /// <value>The target property represents the value of the target object.</value>
	
    [SerializeField]
    private Vector3 offsetPosition;
	/// <summary>The offsetPosition property represents the camera's offest position.</summary>
    /// <value>The offsetPosition property represents the camera's offest position in relation to the target.</value>
	
    [SerializeField]
    private Space offsetPositionSpace = Space.Self;
	/// <summary>The offsetPositionSpace property represents the camera's starting position.</summary>
    /// <value>The offsetPositionSpace property represents the camera's starting position in relation to the target.</value>
	
    [SerializeField]
    public bool lookAt;
	/// <summary>The lookAt property tells how the camera should focus.</summary>
    /// <value>The lookAt property determines if the camera looks at the target or follows its orientation.</value>
	
	
	/// <summary>Update is a method called when the scene updates.</summary>
    private void Update()
    {
        Refresh();
    }

	/// <summary>Refresh is a method called to refresh variable values.</summary>
    public void Refresh()
    {
        if (target == null)
        {
            Debug.LogWarning("Missing target ref !", this);

            return;
        }

        // Computes position
        transform.position = target.position + offsetPosition;

        if (lookAt)
        {
            transform.position = target.position + offsetPosition;
        }
        else
        {
            transform.position = target.TransformPoint(offsetPosition);
        }

        // Computes rotation
        if (lookAt)
        {
            transform.LookAt(target);
        }
        else
        {
            //float moveHorizontal = Input.GetAxis("Horizontal");
            //transform.Rotate(Vector3.up, moveHorizontal * 40 * Time.deltaTime);

			///Rotate based on mouse movement
            float mouseHorizontal = Input.GetAxis("Mouse X");
            float mouseVertical = Input.GetAxis("Mouse Y");
            transform.Rotate(Vector3.up, mouseHorizontal);
            transform.Rotate(Vector3.right, -mouseVertical);
        }
    }
}